import 'package:flutter/material.dart';
import '../models/product.dart';

class ProductDetailPage extends StatelessWidget {
  final Product product;

  const ProductDetailPage({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.title),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.network(
                product.thumbnail,
                height: 200,
                errorBuilder: (context, error, stackTrace) =>
                    const Icon(Icons.broken_image, size: 100),
              ),
            ),
            const SizedBox(height: 16),
            Text(product.title, style: Theme.of(context).textTheme.titleLarge),
            Text('Brand: ${product.brand}'),
            Text('Price: Rp${product.price.toStringAsFixed(0)}'),
            Text('Discount: ${product.discountPercentage}%'),
            Text('Rating: ${product.rating} / 5'),
            const SizedBox(height: 8),
            Text(product.description),
            const Divider(height: 32),
            Text('Stock: ${product.stock}'),
            Text('Category: ${product.category}'),
            Text('SKU: ${product.sku}'),
            Text('Weight: ${product.weight}g'),
            Text(
                'Dimensions: ${product.dimensions.width} x ${product.dimensions.height} x ${product.dimensions.depth} cm'),
            const Divider(height: 32),
            Text('Shipping Info: ${product.shippingInformation}'),
            Text('Warranty Info: ${product.warrantyInformation}'),
            Text('Availability: ${product.availabilityStatus}'),
            Text('Return Policy: ${product.returnPolicy}'),
            Text('Minimum Order: ${product.minimumOrderQuantity} pcs'),
            const Divider(height: 32),
            Text('Created At: ${product.meta.createdAt.toLocal()}'),
            Text('Updated At: ${product.meta.updatedAt.toLocal()}'),
            Text('Barcode: ${product.meta.barcode}'),
            Text('QR Code: ${product.meta.qrCode}'),
            const Divider(height: 32),
            const Text('Images:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: product.images
                    .map((img) => Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: Image.network(
                            img,
                            height: 100,
                            errorBuilder: (context, error, stackTrace) =>
                                const Icon(Icons.broken_image),
                          ),
                        ))
                    .toList(),
              ),
            ),
            const Divider(height: 32),
            const Text('Reviews:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Column(
              children: product.reviews.map((review) {
                return ListTile(
                  title: Text('${review.reviewerName} (${review.rating}/5)'),
                  subtitle: Text(review.comment),
                  trailing: Text('${review.date.toLocal()}'.split(' ')[0]),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
