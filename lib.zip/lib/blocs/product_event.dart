abstract class ProductEvent {}

class LoadProducts extends ProductEvent {}
