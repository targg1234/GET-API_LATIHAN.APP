import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:latihan_4/blocs/product_event.dart';
import 'package:latihan_4/blocs/product_state.dart';
import 'package:latihan_4/services/product_service.dart';

class ProductBloc extends Bloc<ProductEvent, ProductState> {
  final ProductService productService;

  ProductBloc(this.productService) : super(ProductInitial()) {
    on<LoadProducts>(_onLoadProducts);
  }

  Future<void> _onLoadProducts(
    LoadProducts event,
    Emitter<ProductState> emit,
  ) async {
    emit(ProductLoading());
    try {
      final products = await productService.fetchProducts();
      emit(ProductLoaded(products));
    } catch (e, stacktrace) {
      print('Error loading products: $e');
      print(stacktrace);
      emit(ProductError('Gagal memuat produk. Silakan coba lagi.'));
    }
  }
}
